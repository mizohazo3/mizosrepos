<?php
date_default_timezone_set("Africa/Cairo");
require 'db.php';

// Set headers to prevent caching
header('Cache-Control: no-cache, must-revalidate');
header('Expires: 0');
header('Content-Type: text/plain');

// Check if ID is provided and valid
if (isset($_GET['id']) && !empty($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);
    
    try {
        // Start transaction
        $con->beginTransaction();

        // First get the medication details before deleting
        $getMedInfo = $con->prepare("SELECT medname FROM medtrack WHERE id = ?");
        $getMedInfo->execute([$id]);
        
        if ($getMedInfo->rowCount() > 0) {
            $medInfo = $getMedInfo->fetch();
            $medname = $medInfo['medname'];
            
            // Delete the record from medtrack
            $deleteDose = $con->prepare("DELETE FROM medtrack WHERE id = ?");
            $result = $deleteDose->execute([$id]);
            
            if ($result) {
                // Check if this was the last record for this medication
                $getMostRecent = $con->prepare("SELECT * FROM medtrack WHERE medname = ? ORDER BY STR_TO_DATE(dose_date, '%d %M, %Y %h:%i %p') DESC LIMIT 1");
                $getMostRecent->execute([$medname]);
                
                if ($getMostRecent->rowCount() > 0) {
                    // There's still at least one record for this medication
                    $recentRecord = $getMostRecent->fetch();
                    $lastdose = $recentRecord['dose_date'];
                    
                    // Update the lastdose in medlist
                    $updateLastdose = $con->prepare("UPDATE medlist SET lastdose = ? WHERE name = ?");
                    $updateLastdose->execute([$lastdose, $medname]);
                } else {
                    // No records left for this medication, set lastdose to empty
                    $updateLastdose = $con->prepare("UPDATE medlist SET lastdose = '' WHERE name = ?");
                    $updateLastdose->execute([$medname]);
                }
                
                // Commit the transaction
                $con->commit();
                
                echo "success";
            } else {
                // Rollback on failure
                $con->rollBack();
                echo "error: Failed to delete record";
            }
        } else {
            $con->rollBack();
            echo "error: Record not found";
        }
    } catch (PDOException $e) {
        // Rollback on exception
        if ($con->inTransaction()) {
            $con->rollBack();
        }
        
        // Log the error (in a production environment, don't expose the full error to users)
        error_log("Delete record error: " . $e->getMessage());
        echo "error: Database error occurred";
    }
} else {
    echo "error: Invalid ID provided";
}
?> 